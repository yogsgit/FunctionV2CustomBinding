﻿using Microsoft.ApplicationInsights.DataContracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace RealtimeCommunication.Logging
{
    public interface IFunctionLogger
    {
        void LogTrace(string message
            , string functionName
            , SeverityLevel severityLevel = SeverityLevel.Information
            , Category category = Category.None
            , SubCategory subCategory = SubCategory.None
            , object objectToLog = null
            , string kapRequestId = null
            , string kapSessionId = null);

        void LogException(Exception ex
            , string functionName
            , string message = null
            , Category category = Category.None
            , SubCategory subCategory = SubCategory.None
            , object objectToLog = null
            , string kapRequestId = null
            , string kapSessionId = null);
    }
}
