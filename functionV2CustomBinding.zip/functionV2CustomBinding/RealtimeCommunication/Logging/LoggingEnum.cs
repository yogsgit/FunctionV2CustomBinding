﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealtimeCommunication.Logging
{
    public enum Category
    {
        Startup,
        Migrations,
        Request,
        Event,
        None
    }

    public enum SubCategory
    {
        Incoming,
        Outgoing,
        None
    }
}
