﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Newtonsoft.Json;
using RealtimeCommunication.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace RealtimeCommunication.Logging
{
    public class FunctionLogger : IFunctionLogger
    {
        private readonly TelemetryClient telemetryClient;
        private readonly IConfigHelper configHelper;

        public FunctionLogger(TelemetryClient telemetryClient, IConfigHelper configHelper)
        {
            this.telemetryClient = telemetryClient;
            this.telemetryClient.InstrumentationKey = configHelper.AppInsightsIntrumentationKey;
            this.configHelper = configHelper;
        }

        public void LogTrace(string message
            , string functionName
            , SeverityLevel severityLevel = SeverityLevel.Information
            , Category category = Category.None
            , SubCategory subCategory = SubCategory.None
            , object objectToLog = null
            , string kapRequestId = null
            , string kapSessionId = null)
        {
            var properties = new Dictionary<string, string>();
            properties.Add("service", configHelper.ServiceName);
            properties.Add("level", Enum.GetName(typeof(SeverityLevel), severityLevel));
            if (category != Category.None)
                properties.Add("category", Enum.GetName(typeof(Category), category));
            if (subCategory != SubCategory.None)
                properties.Add("subcategory", Enum.GetName(typeof(SubCategory), subCategory));
            if (!string.IsNullOrEmpty(kapRequestId))
                properties.Add("kapRequestId", kapRequestId);
            if (!string.IsNullOrEmpty(kapSessionId))
                properties.Add("kapSessionId", kapSessionId);
            properties.Add("functionName", functionName);
            properties.Add("message", message);
            if (objectToLog != null)
                properties.Add(objectToLog.GetType().ToString(), JsonConvert.SerializeObject(objectToLog));

            telemetryClient.TrackTrace(message, severityLevel, properties);
        }

        public void LogException(Exception ex
            , string functionName
            , string message = null
            , Category category = Category.None
            , SubCategory subCategory = SubCategory.None
            , object objectToLog = null
            , string kapRequestId = null
            , string kapSessionId = null)
        {
            var properties = new Dictionary<string, string>();
            properties.Add("service", configHelper.ServiceName);
            properties.Add("level", Enum.GetName(typeof(SeverityLevel), SeverityLevel.Error));
            if (category != Category.None)
                properties.Add("category", Enum.GetName(typeof(Category), category));
            if (subCategory != SubCategory.None)
                properties.Add("subcategory", Enum.GetName(typeof(SubCategory), subCategory));
            if (!string.IsNullOrEmpty(kapRequestId))
                properties.Add("kapRequestId", kapRequestId);
            if (!string.IsNullOrEmpty(kapSessionId))
                properties.Add("kapSessionId", kapSessionId);
            properties.Add("functionName", functionName);
            if (!string.IsNullOrEmpty(message))
                properties.Add("message", message);
            if (objectToLog != null)
                properties.Add(objectToLog.GetType().ToString(), JsonConvert.SerializeObject(objectToLog));

            telemetryClient.TrackException(ex, properties);
        }
    }
}
