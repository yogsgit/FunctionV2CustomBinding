using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Extensions.SignalRService;
using RealtimeCommunication.Extensions;
using RealtimeCommunication.Infrastructure;
using RealtimeCommunication.Logging;
using Microsoft.ApplicationInsights.DataContracts;
using System.Net.Http;
using System.Net;

namespace RealtimeCommunication.Functions
{
    public static class GetSignalRConnDetails
    {
        [FunctionName("Negotiate")]
        public static HttpResponseMessage Run(
            [HttpTrigger(AuthorizationLevel.Anonymous)] HttpRequest req,
            [Inject(typeof(IFunctionLogger))]IFunctionLogger functionLogger,
            [Inject(typeof(IConfigHelper))]IConfigHelper configHelper,
            IBinder binder,
            ExecutionContext context)
        {
            string kapRequestId = null;
            string kapSessionId = null;
            try
            {
                var connectionInfo = binder.Bind<SignalRConnectionInfo>(new SignalRConnectionInfoAttribute() { HubName = configHelper.KapEnv, ConnectionStringSetting = "AzureSignalRConnectionString" });

                var res = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new JsonContent(connectionInfo)
                };
                return res;
            }
            catch (Exception ex)
            {
                functionLogger.LogException(ex, context.FunctionName, "Error getting SignalRConnectionInfo.", Category.Request, SubCategory.Outgoing, null, kapRequestId, kapSessionId);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("Internal server error.")
                };
            }
        }
    }
}
