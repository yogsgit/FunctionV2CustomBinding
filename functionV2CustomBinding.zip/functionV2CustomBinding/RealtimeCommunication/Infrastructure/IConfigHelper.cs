﻿
namespace RealtimeCommunication.Infrastructure
{
    public interface IConfigHelper
    {
        string ServiceName { get; set; }
        string AppInsightsIntrumentationKey { get; set; }
        string KapEnv { get; set; }
        string ServiceBusConnectionString { get; set; }
    }
}
