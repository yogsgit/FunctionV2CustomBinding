﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealtimeCommunication.Infrastructure
{
    public class ConfigHelper : IConfigHelper
    {
        public string ServiceName { get; set; }
        public string AppInsightsIntrumentationKey { get; set; }
        public string KapEnv { get; set; }
        public string ServiceBusConnectionString { get; set; }

        public ConfigHelper()
        {
            ServiceName = Environment.GetEnvironmentVariable("ServiceName");
            AppInsightsIntrumentationKey = Environment.GetEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY");
            KapEnv = Environment.GetEnvironmentVariable("KapEnv");
            ServiceBusConnectionString = Environment.GetEnvironmentVariable("ServiceBusConnectionString");
        }
    }
}
