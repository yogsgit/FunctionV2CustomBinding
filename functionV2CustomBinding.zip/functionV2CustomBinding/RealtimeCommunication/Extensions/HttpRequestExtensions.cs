﻿using Microsoft.AspNetCore.Http;
using System.Linq;

namespace RealtimeCommunication.Extensions
{
    public static class HttpRequestExtensions
    {
        public static string GetHeader(this IHeaderDictionary headers, string name)
        {
            return headers != null
                           ? headers.ContainsKey(name)
                               ? headers.GetCommaSeparatedValues(name).FirstOrDefault()
                               : null
                           : null;
        }
    }
}
